import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.TreeMap;
/**
 * Prof.Anu Thomas
 * @author Maryam Afshar
 * course: Data structure
 * program: Computer Engineering Technology
 * Date: 2020-11-20
 * Assignment3.java
 * purpose: a program which builds a tree �dictionary� 
 * of words that were found in a piece of text and keep track of how many 
 * occurrences there were of each of the words.
 */
public class Dictionary {
    //Create a treeMap object
	//TreeMap<K,V> k-the type of keys maintained by this map
	//             v-the type of map values
	private TreeMap<String, Integer> tree = new TreeMap();
	private Scanner input = new Scanner(System.in);
    /**
     * this method get the text from user input  
     * and add words by user
     * @return the number of word that the user entered
     */
	public TreeMap<String, Integer> addWordByUser() {

		String getLine, tmp;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter text:");
		
		getLine = scanner.nextLine();
		getLine = getLine.toLowerCase();
		
		Scanner s = new Scanner(getLine);
		while (s.hasNext()) {
			tmp = s.next();
			//Returns true if this map contains
			//a mapping for the specified key.
			if (tree.containsKey(tmp)) {
				tree.put(tmp, (tree.get(tmp) + 1));
			} else {
				tree.put(tmp, 1);
			}

		}
		return tree;
	}
    /**
     * this method reads text from the file
     * @return tree
     */
	public TreeMap<String, Integer> addWrodByFile() {

		File f = new File("Oliver.txt");
		String tmp;
		try {
			Scanner scan = new Scanner(f);

			while (scan.hasNext()) {
				tmp = scan.next();
				tmp = tmp.toLowerCase();
                //Returns true if this map contains
				//a mapping for the specified key.
				if (tree.containsKey(tmp)) {
					tree.put(tmp, (tree.get(tmp) + 1));
				} else {
					tree.put(tmp, 1);
				}

			}

		} catch (FileNotFoundException e) {
			System.out.println("File not found!");
		}

		return tree;
	}
    /**
     * this method search a word in dictionary
     * @return tree
     */
	public TreeMap<String, Integer> searchNodes() {
		
		System.out.print("Enter the word you want to search: ");
		String tmp = input.next();
		//it returns words does'nt matter upper or lower case
		tmp = tmp.toLowerCase();

		int n = 0;
        //Returns true if this map contains a
		//mapping for the specified key.
		if (tree.containsKey(tmp)) {
			n = tree.get(tmp);
		}
		System.out.println(tmp + " occurs " + n + " times");

		return tree;
	}
    /**
     * this method Returns the number of key-value mappings in this map.
     * display number of nodes in dictionary
     * @return the size of tree map
     */
	public int sizeOfNodes() {

		return tree.size();
	}
    /**
     * this method removes all mappings from this tree Map
     * it resets the dictionary
     * @return tree
     */
	public TreeMap<String, Integer> reset() {
		tree.clear();

		return tree;
	}

}
