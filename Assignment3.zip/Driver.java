import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.TreeMap;
/**
 * Prof.Anu Thomas
 * @author Maryam Afshar
 * course: Data structure
 * program: Computer Engineering Technology
 * Date: 2020-11-20
 * Assignment3.java
 * purpose: a program which builds a tree �dictionary� 
 * of words that were found in a piece of text and keep track of how many 
 * occurrences there were of each of the words.
 */
public class Driver {
    /**
     * this main method contains 5 choices
     * @param args which is for main method
     */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Dictionary d = new Dictionary();

		boolean loop = true;
		boolean	loop2 = true;
		Scanner input = new Scanner(System.in);
		int choice = -1;
		int choice2 = -1;

		do {
			System.out.print("*********************************************\r\n" + "          DICTIONARY\r\n"
					+ "*********************************************\r\n" + "1. Add words to the Dictionary\r\n"
					+ "2. Search a word in the Dictionary\r\n" + "3. Display number of nodes in the Dictionary\r\n"
					+ "4. Reset Dictionary\r\n" + "5. Exit\r\n" + "Enter your option: ");
               try {
			//if (input.hasNextInt())
				choice = input.nextInt();
			//else {
               }catch(InputMismatchException er) {
				System.err.println("Input Mismatch Exception while reading user's option from main menu");
				input.next();
			}

			switch (choice) {
			case 1:
				do {
					
					System.out.print("1. Read text from the user\r\n" + "2. Read text from a file "
							+ "\n3. Go back to main menu " + "\nEnter your choice:");
					try {
					//if (input.hasNextInt())
					choice2 = input.nextInt();
					} catch(InputMismatchException er){ 
						System.err.println("Input Mismatch Exception while reading user's option from main menu");
						input.next();
					}
					//else {
						
					//}
					

					switch (choice2) {
					case 1:
						d.addWordByUser();
						break;
					case 2:
						d.addWrodByFile();
						break;
					case 3:
						System.out.println("Exiting from here.... going back to main menu");
						loop2 = false;
						break;
					default:
						System.out.println("Please choose from menu!");
					}

				} while (loop2);

				break;
			case 2:
				
                d.searchNodes();
				break;
			case 3:
				System.out.println("Dictionary has " + d.sizeOfNodes() + " nodes");
				break;
			case 4:
				d.reset();
				break;
			case 5:
				System.out.println("GoodBye... have a nice day");
				loop = false;
				break;
			default:
				System.out.println("Please choose from the menu !");
			}

		} while (loop);
	}

	}


