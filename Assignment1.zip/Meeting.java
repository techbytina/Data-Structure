/**   This class models a meeting which is a type of events.
 *	  Author:  Maryam Afshar
 *	  Edited by: Maryam Afshar
 *
 *    this class extends the Event class
 *	  Data fields:  location: String  - location of the meeting 
 *                  
 *    Methods:  
 *				toString:String - displays values of meeting 
 *				readInfo(Scanner) - prompts user to enter info of meeting for data fields from keyboard - with validity checks   
 *			**  readFromFile(Scanner) - reads meeting values from the file - with validity checks   
 */


package Assignment;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Meeting extends Event {
  private String location;
  
  
  public String toString() {
	  return location;
  }
  
  public void readInfo(Scanner input) {
	  OurDate d1 = new OurDate();
		OurTime t1 = new OurTime();
		 
		 d1.readDate(input);
		t1.readTime(input);
		 System.out.print("Enter description: ");
		 
	        description = input.next();
	        
	        System.out.print("Enter meeting location: ");
			 
	        location = input.next();
  }
  
  public void readFromFile(Scanner input) {
	  
  }
}
