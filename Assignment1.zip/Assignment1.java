/**   This class is the main class.
 *	  Author: Maryam Afshar 
 *	  Updated by Maryam Afshar
 *    This program  will develop a tool that you can use to keep track of activities (events) � a basic electronic
      planner.
 *	  Data fields:  
 *                    int option = -1;
		              Scanner scan = new Scanner(System.in);
		              Planner p1 = new Planner();
		             
 *                 
 *    Methods:  
 *              main (String[] args): 8 possible options defined in this method to run the code by main method
 *				                      using a while loop to repeat options during run the program
 *                                    by entering option 8, finish the program
 *				
 */


package Assignment;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Assignment1 {
	public static void main(String[] args) {
		int option = -1;
		Scanner scan = new Scanner(System.in);
		Planner p1 = new Planner();
		p1.printTitle();

		while (option != 8) {
			System.out.println("1 ... Add an event from keyboard\r\n" + "2 ... Display events of a day\r\n"
					+ "3 ... Display events of a week\r\n" + "4 ... Display events of a month\r\n"
					+ "5 ... Delete an event\r\n" + "6 ... Add events from a file\r\n" + "7 ... Display all events\r\n"
					+ "8 ... Quit");
			System.out.println("Enter your option: ");
			try {
				option = scan.nextInt();
			} catch (InputMismatchException ime) {
				System.err.println("****Input mismatch exception****");
				scan.nextLine();
			}

			if (option == 1) {

				p1.addEvent(scan);

			}

			else if (option == 2) {
				p1.displayEventsdaily(null);
			}

			else if (option == 3) {
                p1.displayEventsWeekly(null);
			} 
			else if (option == 4) {
                p1.displayEventsMonthly(null);
			} 
			else if (option == 5) {

			} 
			else if (option == 6) {
				p1.readEventsFromFile(scan);

			} 
			else if (option == 7) {
				p1.displayAllEvents();

			} 
			else if (option == 8) {
				System.out.println("Good Bye.... have a nice day");
			}
		}

	}
}
