/**   This class models a work event which is a type of events.
*	  Author:  Maryam Afshar
*	  Edited by: Maryam Afshar
*    this class extends the Event class
*	    
*
*    Data fields:  
*              location: String  
*              numHours: double  
*                  
*    Methods:  
*				toString:String - returns an string
*              readInfo(Scanner input): void- get the info of  work event from user
*              readFromFile(Scanner input):void- read work events from file
*              
*				  
*/
package Assignment;

import java.util.Scanner;

public class Work extends Event {
	private String location;
	private double numHours;

	public String toString() {
		return toString();
	}

	public void readInfo(Scanner input) {
		OurDate d1 = new OurDate();
		OurTime t1 = new OurTime();

		d1.readDate(input);
		t1.readTime(input);

		System.out.print("Enter description: ");

		description = input.next();
		System.out.print("Enter work location: ");

		location = input.next();

		System.out.print("Enter number of hourse  worked: ");
		numHours = input.nextDouble();
	}

	public void readFromFile(Scanner input) {

	}
}
