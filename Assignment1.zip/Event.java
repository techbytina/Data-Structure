/**   This class models an Event.
 *	  Author:  Maryam Afshar 
 *	  Updated by Maryam Afshar
 *   
 *	  Data fields:  description: String 
 *                  
 *                 
 *    Methods:  no-arg constructor
 *              initial constructors
 *				
 *              
 *			**	isEqual (Event e): boolean - returns whether current event object has same event as parameter
 *          **  isGreater (Event e):boolean - compares two events if they're same
 *                                            greater than the parameter object; else returns false  
 *				toString:String - displays values of event to String
 *				readInfo (Scanner) - prompts user to enter values from the keyboard - with validity checks 
 *                                   getting the information of an event
 *			**  readFromFile(Scanner) - read data from the file - with validity checks                        
 *				
 */

package Assignment;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Event {
	protected String description;

	Event() {

	}

	Event(OurDate date, OurTime time, String desc) {
        
	}

	public String toString() {
		return description;
	}

	public boolean isEqual(Event e) {
		return true;
	}

	public boolean isGreater(Event e) {
		return false;
	}

	public void readInfo(Scanner input) {
		OurDate d1 = new OurDate();
		OurTime t1 = new OurTime();
		 
		 d1.readDate(input);
		 t1.readTime(input);
		 
		 System.out.println("Enter description: ");
		 
        description = input.next();

	}

	public void readFromFile(Scanner input) {
		
		

	}

}
