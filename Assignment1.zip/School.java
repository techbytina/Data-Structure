  
 /**   This class models a school event which is a type of events.
 *	  Author:  Maryam Afshar
 *	  Edited by: Maryam Afshar
 *    this class extends the Event class
 *	  
 *                  
 *    Methods:  
 *				toString:String - returns an string
 *				  
 */

package Assignment;

public class School extends Event {
	
   public String toString() {
	   return toString();
   }
}
