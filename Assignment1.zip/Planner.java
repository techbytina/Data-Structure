
/**   This class models an Event planner.
 *	  Author:  Maryam Afshar
 *	  Edited by: Maryam Afshar
 *	  Data fields:  events: ArrayList -Private
 *                  
 *    Methods:  no-arg constructor
 *              initial constructors
 *				displayEventsDaily(OurDate date):void - This method display the daily events
 *              displayAllEvents:void - it displays all events that we created and also is in the file
 *				
 *              printTitle() : void - This method prints the title of the program                            
 *				displayEventsdaily(OurDate date):void - displays all of the daily events
 *				displayEventsWeekly(OurDate date):void - displays all of the weekly events  
 *              deleteEvents(OurDate myDate, OurTime myTime): void- delete that target events that user wants to delete
 *              binarySearch(Event temp): int- returns an integer- this methods search to find the target event
 *              findPosition(Event e): int - this method finds the position of the specific method
 *              readEventsFromFile(Scanner input):void - reads events from the file 
 *             addEvent(Scanner input):void- this method add events to the file of the events
 *			 
 */

package Assignment;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Planner {
	private ArrayList<Event> events;

	Planner() {
		events = new ArrayList<Event>();
	}

	public void displayEventsMonthly(OurDate date) {
		System.out.println("Enter the month for which events to be displayed: ");
		OurDate d1 = new OurDate();
		d1.getMonth();

	}

	public void displayAllEvents() {

	}

	public void printTitle() {
		for (int i = 0; i < 45; i++) {
			System.out.print("=");
		}
		System.out.println("\n\n              Events Planner    \n");
		for (int i = 0; i < 45; i++) {
			System.out.print("=");
		}
		System.out.println();
	}

	public void displayEventsdaily(OurDate date) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the day for which events to be displayed: \n");

		OurDate d1 = new OurDate();
		OurTime t1 = new OurTime();
		d1.readDate(scan);

		System.out.println("Your calendar events for the given date are ");

		System.out.println(d1.toString());
		System.out.println(t1.toString());

	}

	public void displayEventsWeekly(OurDate date) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the day from which events for a week to be displayed: ");

		OurDate d1 = new OurDate();

		d1.readDate(scan);

		System.out.println("Your calendar events for a week starting from the given date are");
	}

	public void deleteEvents(OurDate myDate, OurTime myTime) {

	}

	public int binarySearch(Event temp) {
		return 0;

	}

	public int findPosition(Event e) {
		return 0;
	}

	public void addEvent(Scanner input) {

		System.out.println("1. Meeting\r\n" + "2. School\r\n" + "3. Work\r\n" + "4. Gym\r\n" + "5. Social\r\n" + "");
		int typeOfEvent = 0;
		System.out.println("Enter type of the event: ");
		try {
			typeOfEvent = input.nextInt();
		} catch (InputMismatchException ime) {
			System.err.println("****Input mismatch exception****");
			input.nextLine();
		}

		// int typeOfEvent=0;
		Meeting m1 = new Meeting();
		Work w1 = new Work();
		School s1 = new School();
		Gym g1 = new Gym();
		Social c1 = new Social();

		if (typeOfEvent == 1) {

			m1.readInfo(input);
			events.add(m1);

		} else if (typeOfEvent == 2) {

			s1.readInfo(input);
			events.add(s1);

		} else if (typeOfEvent == 3) {

			w1.readInfo(input);
			events.add(w1);

		} else if (typeOfEvent == 4) {

			g1.readInfo(input);
			events.add(g1);

		} else if (typeOfEvent == 5) {
			c1.readInfo(input);
			events.add(c1);
		}

	}

	public void readEventsFromFile(Scanner input) {
		int hours = 0;
		String location = "";
		try {
			input = new Scanner(Paths.get("/Users/tinaa/Dropbox/My PC (LAPTOP-85KFE5ET)/Documents/Events.txt"));
		} catch (IOException ioe) {
			System.out.println(ioe);
		}
		/*
		 * this part of method reads from the file till the file has information in it
		 */
		while (input.hasNext()) {
			
			int type = input.nextInt();
			int month = input.nextInt();
			int day = input.nextInt();
			int year = input.nextInt();
			int hour = input.nextInt();
			int minutes = input.nextInt();
			String description = input.next();

			OurDate date = new OurDate();
			OurTime time = new OurTime();
			date.setDay(day);
			date.setMonth(month);
			date.setYear(year);
			time.setHour(hour);
			time.setMinute(minutes);
			Event e2 = new Event(date, time, description);
			events.add(e2);

			/*
			 * a for loop is created here to specifies the type of event
			 */
			if (type == 1) {
				location = input.next();
			} else if (type == 3) {
				location = input.next();
				hours = input.nextInt();
			}

			switch (type) {
			case 1:
				System.out.printf("| %7s| %5s| %5s| %6s | %6s |%20s |%9s \n", month, day, year, hour, hours,
						description, location);
				break;

			case 3:
				System.out.printf("| %7s| %5s| %5s| %6s | %6s |%20s |%9s |%4s \n", month, day, year, hour, hours,
						description, location, hours);
				break;

			case 2:
				System.out.printf("| %7s| %5s| %5s| %6s | %6s |%20s  \n", month, day, year, hour, hours, description);
				break;
			case 4:
				System.out.printf("| %7s| %5s| %5s| %6s | %6s |%20s  \n", month, day, year, hour, hours, description);
				break;
			default:
				System.out.printf("| %7s| %5s| %5s| %6s | %6s |%20s  \n", month, day, year, hour, hours, description);

			}

		}
		

		/**
		 * this part of method closes the file
		 */

		if (input != null) {
			input.close();
		}

	}

}
