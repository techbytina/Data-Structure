package Assignment2;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/***********************************************************************************
Class:  EmailAddress
Purpose:  This class will model the data and actions needed for a directory 
@author :  Maryam Afshar

Course:   CST8130 - Data Structures     	          
*************************************************************************************/
public class Directory {
	 String name;
	    int emailAmm;
	    String emails;
	    String listName;
	    private static File file = new File("emails.txt");

	    public void addEmailAddress(Scanner input) {

	    }

	    public void deleteEmailAddress(Scanner input) {
	        System.out.print("Enter name of the list you which to delete: ");
	        listName = input.next();
	    }

	    public void createEmailList(Scanner input) {

	    }

	    public void displayEmailLists() {
	        
	    }

	    public void displayOneEmailList(Scanner input) {
	        
	    }

	    public void readFromFile(Scanner input) {
	      
	        try {

	            input = new Scanner(file);
	            while (input.hasNext()) {
	                 name = input.next();
	                emailAmm = input.nextInt();
	                 emails = input.next();
	                printAll();
	            }
	            input.close();
	        } catch (FileNotFoundException error) {
	            System.out.println("File was not found...");
	            error.printStackTrace();

	        }

	    }



	  
	    public void printAll(){
	        System.out.printf("%5s|%5d|%5s|", name, emailAmm, emails);
	    }
	}


