package Assignment2;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;
/***********************************************************************************
Class:  EmailList
Purpose:  This class will model the data and actions needed for an email List data type
@author :   Maryam Afshar
Course:   CST8130 - Data Structures     	          
*************************************************************************************/

public class EmailList extends Directory{

    private String listName;
    private ArrayList<String> emailAddress;
    private LinkedList<EmailAddress> addressList;
//will have a linked list of email addresses
//email address list contains string name a list and a linked list of email addresses objects
    public EmailList(){
        listName = new String();
    }

    public EmailList(String name){
        emailAddress = new ArrayList<String>();
        listName = name;
        emailAddress.add(listName);
    }

    
    public void setLink(LinkedList<EmailAddress> addresseList){
        this.addressList = addresseList;
    }
    
    public LinkedList<EmailAddress> getLink(){
        return addressList;
    }
    

    public String toString() {
            String all = emailAddress.toString();
        return all;
    }
}

