package Assignment2;

import java.util.InputMismatchException;
import java.util.Scanner;
/***********************************************************************************
Class:  EmailAddress
Purpose: This class is included the main method which is included the 7 choices
@author :   Maryam Afshar

Course:   CST8130 - Data Structures     	          
*************************************************************************************/
public class Assignment2 {
	 public static void main(String[] args) {
	        Directory d1 = new Directory();
	        Scanner input = new Scanner(System.in);

	        int ans = 0;
	        while (ans != 7) {
	            try {
	                System.out.println(
	                        "=====================================================\n                   Email Directory\n=====================================================\n1. Add a new email address to an existing email list\n2. Delete an email address from an existing email list\n3. Create an email list\n4. Display all email lists with all email addresses\n5. Display email addresses of a specific email list\n6. Read email lists from a file\n7. Exit\n Enter your choice: ");
	                ans = input.nextInt();
	                switch (ans) {
	                    case 1:
	                        d1.addEmailAddress(input);
	                        break;
	                    case 2:
	                        d1.deleteEmailAddress(input);
	                        break;
	                    case 3:
	                        d1.createEmailList(input);
	                        break;
	                    case 4:
	                        d1.displayEmailLists();
	                        break;
	                    case 5:
	                        d1.displayOneEmailList(input);
	                        break;
	                    case 6:
	                        d1.readFromFile(input);
	                        break;
	                    case 7:
	                        System.out.println("Good Bye... Have a nice day");
	                        break;
	                    default:
	                        System.out.println("Input was invalid");
	                }
	            } catch (InputMismatchException im) {
	                String incorrect = input.next();
	                System.out.println("Input was invalid");
	            }
	        }
	    }
	}


